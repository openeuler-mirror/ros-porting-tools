#ifndef __NSIGHTCHECKER_H__
#define __NSIGHTCHECKER_H__

namespace Ogre
{ 
	bool IsWorkingUnderNsight(); // caches result internally
}

#endif
