#!/usr/bin/python

import simple_test

simple_test.test("test7", ["2", "-n", "homer", "-n", "bart", "6", ], expect_fail=True)
