#!/usr/bin/python

import simple_test

simple_test.test("test5", ["-a", "asdf", "-c", "fdas", "--eee", "blah", "-i", "sss", "-i", "fdsf", ])
