#!/usr/bin/python

import simple_test

simple_test.test("test5", ["-a", "fdsa", "-b", "asdf", "-c", "fdas", ], expect_fail=True)
