#!/usr/bin/python

import simple_test

simple_test.test("test29", ["-a", "5", "-b", "7", ], expect_fail=True)
