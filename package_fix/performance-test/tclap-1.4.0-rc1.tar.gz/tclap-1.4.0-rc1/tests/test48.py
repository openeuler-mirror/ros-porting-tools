#!/usr/bin/python

import simple_test

simple_test.test("test8", ["-s=aaa", "homer", "marge", "bart", "--", "one", "two", ])
