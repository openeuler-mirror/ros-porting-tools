#!/usr/bin/python

import simple_test

simple_test.test("test46", [], expect_fail=True)
