#!/usr/bin/python

import simple_test

simple_test.test("test20", ["-a", "-b", ], expect_fail=True)
