#!/usr/bin/python

import simple_test

simple_test.test("test35", ["-h", "-a", "5", ])
