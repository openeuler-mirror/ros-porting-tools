*************************
Basic Reading and Writing
*************************

Reading messages
----------------

.. literalinclude:: ../examples/raw/reader.py

Writing messages
----------------
.. literalinclude:: ../examples/raw/writer.py
