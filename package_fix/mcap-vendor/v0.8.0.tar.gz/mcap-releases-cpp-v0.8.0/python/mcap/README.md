# MCAP Python Library

This library provides classes for reading and writing the MCAP file format.
