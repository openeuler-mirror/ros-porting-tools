from .warning import deprecation_notice

from ..well_known import *  # noqa: F401,F403

deprecation_notice()
