from .warning import deprecation_notice

from ..writer import *  # noqa: F401,F403

deprecation_notice()
