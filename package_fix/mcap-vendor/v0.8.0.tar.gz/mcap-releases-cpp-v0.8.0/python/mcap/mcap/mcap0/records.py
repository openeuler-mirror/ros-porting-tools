from .warning import deprecation_notice

from ..records import *  # noqa: F401,F403

deprecation_notice()
