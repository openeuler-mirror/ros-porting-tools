package mcap

// Version of the MCAP library.
var Version = "v0.3.0"
